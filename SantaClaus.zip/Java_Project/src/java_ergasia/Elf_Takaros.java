/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_ergasia;

import java.util.ArrayList;

/**
 *
 * @author Παναγιώτης
 */
public class Elf_Takaros {
     public Elf_Takaros() {

    }
    // kano mia methodo gia ton Taki opou tha pernei ta dora apo to ergostasio kai tha ta vazei sto sako
    public void Deliver_Gift(ArrayList<Gift> factory, ArrayList<Gift> bag) {
        for (int i = 0; i < factory.size(); i++) {
            Gift myObject = factory.get(0);
            bag.add(myObject);
        }
    }

}
