/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_ergasia;

/**
 *
 * @author Παναγιώτης
 */
public class Gift { 
     private int ID;
     
     // kano ta dora mazi me to id tous
     public Gift(int ID) {
        this.ID = ID; 
     }
     
     // dino to id tou dorou
     public int Gift_ID() {
         return this.ID;
     }                   
}
