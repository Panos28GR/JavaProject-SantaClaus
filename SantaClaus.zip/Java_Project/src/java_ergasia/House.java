/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_ergasia;

/**
 *
 * @author Παναγιώτης
 */
public class House {
    private int Candies;
    private int Children;
     // kano ta spitia me ton arithmo ton glikon kai paidion pou periexoun  
    public House(int Candies, int Children) {
        this.Children = Children;
        this.Candies = Candies;
        
    }
   
    public int Get_Children() {
        return this.Children;
    }   
    public int Get_Candies() {
        return this.Candies;
    }       
}
