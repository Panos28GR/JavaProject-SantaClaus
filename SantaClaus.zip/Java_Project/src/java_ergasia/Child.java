/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_ergasia;

/**
 *
 * @author Παναγιώτης
 */
public class Child {

    private int Name;
    private int ID_House;
    
    // dino gia to kathe paidi to onoma kai to spiti opou menei
    public Child(int Name, int ID_House) {
        this.Name = Name;
        this.ID_House = ID_House;
        
    }
    
     public int Get_Name() {
       return this.Name;
     }
     public int Get_House() {
         return this.ID_House;
     }
}
