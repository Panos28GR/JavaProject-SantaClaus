/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_ergasia;

/**
 *
 * @author Παναγιώτης
 */
public class Santa {
   private int Energy;
   public Santa() {
       Energy = 100;
      
   }
   
   public int eat_candies(int candy) {
       // kano ton agio vasili na troei osa glika borei xoris na parafaei kai me kathe glyko pou troei na pernei +7 zoi
       int i, j=0;
       for(i=0; i<candy; i++){
          if(this.Energy<=99) {
              this.Energy += 7;
               j++;
          }
       }
       // epistrefo to posa glika  exoun meinei sto spiti
       return candy-j;
   }
   // kano mia methodo opou o Agios Vasilis otan dinei ta dora sta paidia tha xanei -11 zoi
   public void Give_Gift(int children){
       this.Energy -= children*11;
       
   }
   
   public int Get_Energy() {
       return this.Energy;
   }
}
