/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_ergasia;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Παναγιώτης
 */
public class Java_Ergasia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // kalo tous constructor kai ta arraylist
        Santa santa_claus = new Santa();
        Bag bag = new Bag();
        Elf_Takaros Takis = new Elf_Takaros();
        Factory factory = new Factory();
        System.out.println("The gifts have been created");
        ArrayList <Child> childList;
        childList = new ArrayList<Child>();
        
        ArrayList <House> houseList;
        houseList = new ArrayList<House>();
        int i=0,j;
        int children = 0;
        Random random = new Random();
        // kano spitia kai vazo mesa ta paidia
        while(children < 214144) {
            j = random.nextInt(4)+1;
            if (children > 214140) {
                j = 214144 - children;
            }
            // kano to spiti me tixaio arithmo glikon kai paidion
            House house = new House(random.nextInt(6), j);
            for(j=0;j<house.Get_Children();j++) {
                Child child = new Child(children, i);
                children++;
                childList.add(child);
            }
            houseList.add(house);
            i++;
        }
        System.out.println("Kids and houses created");
        int candyavailable;
        // kalo ton Taki na parei ta dora apo to ergostasio kai na ta valei stin tsanta
        Takis.Deliver_Gift(factory.getMyList(), bag.getMyList());
        Boolean status = true;
        // kano ton agio vasili na paradosei ta dora
        for(i=0;i<houseList.size();i++) {
            candyavailable = houseList.get(i).Get_Candies();
            for (j=0;j<houseList.get(i).Get_Children();j++) {
                // ton kano na troei glika oso xreiazetai
                candyavailable = santa_claus.eat_candies(candyavailable);
                // paradosi tou dorou
                bag.Give_Gift();
                santa_claus.Give_Gift(1);
            }
            // ton kano na troei oti glika emeinan pou den exei faei
            candyavailable = santa_claus.eat_candies(candyavailable);
            // elegxo an lipothimaei o agios vasilis
            if(santa_claus.Get_Energy()<0) {
                System.out.println("Santa has fainted at house "+i);
                status = false;
                break;
            }
        }
        if (status == true) {
            System.out.println("Gifts delivered");
        }
    }          
    
}
