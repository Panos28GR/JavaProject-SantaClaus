/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_ergasia;

import java.util.ArrayList;

/**
 *
 * @author Παναγιώτης
 */
public class Bag {

    ArrayList<Gift> myList;

    public Bag() {
        // kano to arraylist tis tsantas
        myList = new ArrayList<Gift>();

    }

    public void Give_Gift() {
        myList.remove(0);

    }

    public void Get_Gift(Gift gift) {
        myList.add(gift);

    }
    // dino to arraylist
    public ArrayList<Gift> getMyList() {
        return myList;
    }
}



